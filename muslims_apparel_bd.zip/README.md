"# muslims_apparel" 
# todo: upload images for slider part
# todo: upload images for different typ of product
# todo: showing NEW ARRIVALS, ORGANIC FOOD, BEST SELLING PRODUCT, TOP RATED PRODUCTS type of products to home page
# todo: showing others type of images into product page
# todo: showing single product details
# todo: connect facebook messenger on this site. 
# todo: remove image from directory after update or delete 
# todo: pagination
# todo: fix amount of product will show in the home page.